<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Admin extends BaseController
{
    public function index()
    {
        $model = model('DashboardModel');
        helper('form');

        $data['title'] = 'Admin Dashboard';
        $data['amount'] = array('name' => "amount", 'class' => "form-control filter", 'type' => "text", 'placeholder' => "Enter Withdrawal Amount");
        $data['users'] = $model->get_users();
        
        return view('admin/partials/header', $data) // same header with dashboard
                .view('admin/index', $data)
                .view('dashboard/partials/footer'); // same footer with dashboard
    }
}
